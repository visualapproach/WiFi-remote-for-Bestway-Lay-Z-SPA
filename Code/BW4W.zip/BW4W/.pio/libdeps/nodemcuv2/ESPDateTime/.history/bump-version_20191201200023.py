#!/usr/bin/env python3
import os
import sys
import json
import configparser


def change_lib_json():
    lib = json.loads("library.json")
    print(lib.version)


def change_lib_props():
    cfg = configparser.ConfigParser()
    cfg.read("library.properties")
    print(cfg.version)
