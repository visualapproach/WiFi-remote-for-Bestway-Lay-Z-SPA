#!/usr/bin/env python3
import os
import sys
import json
import regex
import configparser
import semver


def change_json():
    lib = json.loads("library.json")
    print(lib.version)


def change_props():
    cfg = configparser.ConfigParser()
    cfg.read("library.properties")
    print(cfg.version)


def change_readme():
    with open('README.md') as f:
        bf = f.read()
