#!/usr/bin/env python3
import os
import sys
import json
import configparser


def replace_lib_json():
    lib = json.loads("library.json")
    print(lib.version)
