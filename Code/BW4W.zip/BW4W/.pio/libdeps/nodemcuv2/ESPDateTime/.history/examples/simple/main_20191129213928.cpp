
#include <Arduino.h>
#include <ctime>
#include <iomanip>
#include <cstdio>
#include <cstdlib>
#if defined(ESP8266)
#include <ESP8266WiFi.h>
#elif defined(ESP32)
#include <WiFi.h>
#endif
#include "config.h"
#include "ESPDateTime.h"

unsigned long lastMs = 0;

unsigned long ms = millis();

void setupWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.println(millis());
  Serial.print("WiFi Connecting");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
}

void setupDateTime() {
  // setup this after wifi connected
  // you can use custom timeZone,server and timeout
  DateTime.setTimeZone(DateTimeClass::TIMEZONE_CHINA);
  DateTime.setServer(DateTimeClass::NTP_SERVER_1);
  DateTime.begin(DateTimeClass::DEFAULT_TIMEOUT);
}

void setup() {
  delay(1000);
  Serial.begin(115200);
  setupWiFi();
  setupDateTime();
  if (!DateTime.isTimeValid()) {
    Serial.println("Failed to get time from server.");
  }
  Serial.println(DateTime.toString());
  Serial.println(DateTime.toISOString());
  Serial.println(DateTime.toUTCString());
  Serial.println(DateTime.format(DateFormatter::COMPAT));
  Serial.println(DateTime.format(DateFormatter::DATE_ONLY));
  Serial.println(DateTime.format(DateFormatter::TIME_ONLY));
}

void loop() {
  if (millis() - ms > 10000) {
    ms = millis();
    Serial.println("----------");
  }
}