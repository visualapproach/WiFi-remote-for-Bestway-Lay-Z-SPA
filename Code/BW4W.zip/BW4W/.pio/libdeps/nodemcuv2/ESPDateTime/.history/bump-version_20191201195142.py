#!/usr/bin/env python3
import os
import sys
import json


def replace_lib_json():
