#!/bin/sh

VERSION = $1

sed -i 's/\"version\": "\d+\.\d+\.\d+"/${VERSION}/g' library.json
