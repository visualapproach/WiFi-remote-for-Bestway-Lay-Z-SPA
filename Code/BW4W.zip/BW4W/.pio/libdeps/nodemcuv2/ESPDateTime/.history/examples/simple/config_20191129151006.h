
#ifndef ESP_ARDUINO_LABS_CONFIG__H
#define ESP_ARDUINO_LABS_CONFIG__H

#ifndef WIFI_SSID
#define WIFI_SSID "CMCC-9EDc"
#define WIFI_PASS "idqf6rnx"
#endif

#endif