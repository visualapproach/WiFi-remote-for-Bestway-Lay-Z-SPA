#!/bin/sh
pio test -e testnodemcuv2
# pio test -e testnodemcu-32s
